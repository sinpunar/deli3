/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Manreen
 */
public class grupOfCrd {
    //instance variables
     private final ArrayList<Acrd> deck;
     //default constructor without parameters
    public grupOfCrd()
    {
        deck = new ArrayList<>();
        //for statement
        for(int i=0; i<4; i++)
        {
            for(int j=1; j<=13; j++)
            {
                deck.add(new Acrd(i,j));
            }
        }
    }
    //shuffle method
    public void shuffle()
    {
        Collections.shuffle(deck);
    }
    /*
     * Draws a card from the deck.
     */
    //drawCard method
    public Acrd drawCard()
    {
        return deck.remove(0);
    }
}
