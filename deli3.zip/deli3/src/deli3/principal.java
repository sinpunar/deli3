/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;
import java.util.Scanner;
import java.util.List;
import java.util.*;
/**
 *
 * @author Manreen
 */
public class principal extends gme{
    //instance variable declaration
 private static int cash;         
     private static int bet;               
     private static int AceC;         
     private static ArrayList<Acrd> hand;       
     private static int handv;          
     private static String name;
    private final String giveNme;
    //default constructor with parameters
    public principal(String giveName){
        super(giveName);
    }
    //main method
    public static void main(String[] args) {
      principal ref = new principal("name");
        System.out.println("Hi! What is your name?");
        Scanner sc = new Scanner(System.in);
        name = sc.nextLine();
        System.out.println("Hello, " + name + ", lets play some BlackJack!");
        System.out.println("How much cash do you want to start with?");
        Scanner mny = new Scanner(System.in);
        cash = mny.nextInt();
        System.out.println("You start with cash: " + cash);
        while (cash > 0) {
            grupOfCrd deck = new grupOfCrd();
            deck.shuffle();
            AceC = 0;
            person person = new person(deck);
            List<Acrd> hn = new ArrayList<>();
            hn.add(deck.drawCard());
            hn.add(deck.drawCard());
            System.out.println("How much would you like to bet?");
            bet = ref.Bet(cash);
            System.out.println("Cash:" + (cash - bet));
            System.out.println("Money on the table:" + bet);
            System.out.println("Here is your hand: ");
            System.out.println(hn);
            int handvalue = ref.calcHandValue(hn);
            System.out.println("The dealer is showing: ");
            person.showFirstCard();
            //if else statement
            if (ref.hasBlackJack(handv) && person.hasBlackJack()) {
                ref.Push();
          } else if (ref.hasBlackJack(handv))
          {
              System.out.println("You have BlackJack!");
              System.out.println("You win 2x your money back!");
              cash = cash + bet;
              ref.Win();
          } else if (person.hasBlackJack())
          {
              System.out.println("Here is the dealer's hand:");
              person.showHand();
              ref.Lose();
          } else {
              if (2 * bet < cash)
              {
                  System.out.println("Would you like to double down?");//allows the user to double down.
                  Scanner dd = new Scanner(System.in);
                  String duble = dd.nextLine();
                  while (!ref.isyesorno(duble)) {
                      System.out.println("Please enter yes or no.");
                      duble = dd.nextLine();
                  }
                  if (duble.equals("yes")) {
                      System.out.println("You have opted to double down!");
                      bet = 2 * bet;
                      System.out.println("Cash:" + (cash - bet));
                      System.out.println("Money on the table:" + bet);
                  }
              }
              System.out.println("Would you like to hit or stand?");//ask if the user will hit or stand
              Scanner hits = new Scanner(System.in);
              String hit = hits.nextLine();
              while (!ref.isHitorStand(hit)) {
                  System.out.println("Please enter 'hit' or 'stand'.");
                  hit = hits.nextLine();
              }
              while (hit.equals("hit"))
              {
                  ref.Hit(deck, hn);
                  System.out.println("Your hand is now:");
                  System.out.println(hn);
                  handv = ref.calcHandValue(hn);
                  if (ref.checkBust(handv))
                  {
                      ref.Lose();
                      break;
                  }
                  if (handv <= 21 && hn.size() == 5)
                  {
                      ref.fivecardtrick();
                      break;
                  }
                  System.out.println("Would you like to hit or stand?");
                  hit = hits.nextLine();
              }
              if (hit.equals("stand"))
              {
                  int delerhnd = person.takeTurn(deck);
                  System.out.println("");
                  System.out.println("Here is the dealer's hand:");
                  person.showHand();
                  if (delerhnd > 21)
                  {
                      ref.Win();
                  } else {
                      int you = 21 - handv;
                      int deal = 21 - delerhnd;
                      if (you == deal) {
                          ref.Push();
                      }
                      if (you < deal) {
                          ref.Win();
                      }
                      if (deal < you) {
                          ref.Lose();
                      }
                  }
              }
          }
            System.out.println("Would you like to play again?");
            Scanner yn = new Scanner(System.in);
            String ans = yn.nextLine();
            while (!ref.isyesorno(ans)) {
                System.out.println("Please answer yes or no.");
                ans = yn.nextLine();
            }
            if (ans.equals("no")) {
                break;
            }
        }
        System.out.println("Your cash is: " + cash);
        if (cash == 0) {
            System.out.println("You ran out of cash!");
        } else {
            System.out.println("Enjoy your winnings, " + name + "!");
        }
    }
    //win method
    @Override
    public void Win() {
     System.out.println("Congratulations, you win!");
        cash = cash + bet;
        System.out.println("Cash: " + cash);
    }
//hasBlackJack method
    @Override
    public boolean hasBlackJack(int handV) {
        return handV == 21;
    }
//calcHandValue method
    @Override
    public int calcHandValue(List<Acrd> hand) {
     Acrd[] aHnd = new Acrd[]{};
        aHnd = hand.toArray(aHnd);
        int hndv = 0;
        //for statement followed by if statement
     for (Acrd aHnd1 : aHnd) {
         hndv += aHnd1.getPoint();
         if (aHnd1.getPoint() == 11) {
             AceC++;
         }
         //while loop
         while (AceC > 0 && hndv > 21) {
             hndv -= 10;
             AceC--;
         }
     }
        return hndv;
    }
//return method
    /**
     *
     * @param cash
     * @return
     */
    @Override
    public int Bet(int cash) {
    Scanner s = new Scanner(System.in);
        int bt = s.nextInt();
        while (bt > cash) {
            System.out.println("You cannot bet more cash than you have!");
            System.out.println("How much would you like to bet?");
            bt = s.nextInt();
        }
        return bt;
    }
//lose method
    @Override
    public void Lose() {
     System.out.println("Sorry, you lose!");
        cash = cash - bet;
        System.out.println("Cash: " + cash);
    }
//push method
    @Override
    public void Push() {
    System.out.println("It's a push!");
        System.out.println("You get your money back.");
        System.out.println("Cash: " + cash);
    }
//hit method
    @Override
    public void Hit(grupOfCrd deck, List<Acrd> hand) {
     hand.add(deck.drawCard());
        Acrd[] aHnd = new Acrd[]{};
        aHnd = hand.toArray(aHnd);
        handv = 0;
     for (Acrd aHnd1 : aHnd) {
         handv += aHnd1.getPoint();
         if (aHnd1.getPoint() == 11) {
             AceC++;
         }
         while (AceC > 0 && handv > 21) {
             handv -= 10;
             AceC--;
         }
     }
    }
//isHitorStand method
    @Override
    public boolean isHitorStand(String hit) {
        return hit.equals("hit") || hit.equals("stand");
    }
//checkBust method
    @Override
    public boolean checkBust(int handv) {
      if (handv > 21) {
          System.out.println("You have busted!");
          return true;
      } else {
      }
        return false;
    }
//isyesorno method
    @Override
    public boolean isyesorno(String ans) {
        return ans.equals("yes") || ans.equals("no");
    }
//fivecardtrick method
    @Override
    public void fivecardtrick() {
    System.out.println("You have achieved a five card trick!");
        Win();
    }
}