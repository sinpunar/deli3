/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;

/**
 *
 * @author Manreen
 */
public abstract class card {
    //toString method declared 
    @Override
    public abstract String toString();
}
