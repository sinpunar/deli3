/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;

import java.util.ArrayList;

/**
 *
 * @author Manreen
 */
public class person extends player{
    //instance variables
    ArrayList<Acrd> hand;
    private int handv=0;
    private Acrd[] aHnd;
    private int AceC;
    //default constructor with parameters
    public person(grupOfCrd deck)
    {
        super("name");
        hand = new ArrayList<>();
        aHnd = new Acrd[]{};
        int AceC=0;
        //for statement followed by if and while loop
        for(int i=0; i<2; i++)
        {
            hand.add(deck.drawCard());
        }
        aHnd = hand.toArray(aHnd);
        for (Acrd aHnd1 : aHnd) {
            handv += aHnd1.getPoint();
            if (aHnd1.getPoint() == 11) {
                AceC++;
            }
            while(AceC>0 && handv>21)
            {
                handv-=10;
                AceC--;
            }
        }
    }
    //showFirstCard method
    public void showFirstCard()
    {
        Acrd[] firstCard = new Acrd[]{};
        firstCard = hand.toArray(firstCard);
        System.out.println("["+firstCard[0]+"]");
    }
    //Hit method
    public void Hit(grupOfCrd deck)
    {
        hand.add(deck.drawCard());
        aHnd = hand.toArray(aHnd);
        handv = 0;
        //for statement followed by if and while loop
        for (Acrd aHnd1 : aHnd) {
            handv += aHnd1.getPoint();
            if (aHnd1.getPoint() == 11) {
                AceC++;
            }
            while(AceC>0 && handv>21)
            {
                handv-=10;
                AceC--;
            }
        }
    }
    //wantsToHit method
    public boolean wantsToHit()
    {
        return handv<17;
    }
    //hasBlackJack method
    public boolean hasBlackJack()
    {
        if(hand.size()==2 && handv==21)
        {
            System.out.println("The dealer has blackjack!");
            return true;
        }
        return false;
    }
    //showHand method
    public void showHand()
    {
        System.out.println(hand);
    }
    //getter
    public int getHandV()
    {
        return handv;
    }
    //busted mthod
    public boolean busted(int handv)
    {
        if(handv>21)
        {
            System.out.println("The dealer busted!");
            return true;
        }
        return false;
    }
   //takeTurn method
    public int takeTurn(grupOfCrd deck)
    {
        while(wantsToHit())
        {
            System.out.println("The dealer hits");
            Hit(deck);
            if(busted(handv))
            {
                break;
            }
        }
        if(handv<=21)
        {
            System.out.print("The dealer stands.");
        }
        return handv;
    }
}