/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Manreen
 */
public abstract class gme {
    //instance variables
    private final String gmeN;
    private ArrayList <player> players;
    //default constructor with parameters
    public gme(String giveN)
    {
    gmeN=giveN;
    players=new ArrayList();
    }
    //mutator method
    public String getGmeN()
    {
        return gmeN;
    }
    //getter 
    public ArrayList <player> getPlayers()
    {
        return players;
    }
    //setter
    public void setPlayers(ArrayList <player> players)
    {
        this.players = players;
    }
    //various abstract methods declared
    public abstract void Win();
    public abstract boolean hasBlackJack(int handValue);
    public abstract int calcHandValue(List<Acrd> hand);
    public abstract int Bet(int cash);
    public abstract void Lose();
    public abstract void Push();
    public abstract void Hit(grupOfCrd deck, List<Acrd> hand);
    public abstract boolean isHitorStand(String hit);
    public abstract boolean checkBust(int handv);
    public abstract boolean isyesorno(String ans);
    public abstract void fivecardtrick();

}