/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deli3;

/**
 *
 * @author Manreen
 */
public class Acrd extends card{
//instance variable
    private final int rnk;
    private final int deck;
    private int point;
    //default constructor with parameters
    public Acrd(int deck, int points){
        this.rnk= points;
        this.deck= deck;
    }
    //toString method
    @Override
 public String toString()
 {
 return points.points()[rnk] + " of " + deck.values()[deck];
 }
 //getter
 public int getPoint()
 {
     //else if ladder
 if(rnk>10)
 {
 point=10;
 }
 else if(rnk==1)
 {
 point =11;
 }
 else
 {
 point= rnk;
 }
 return point;
 }
}